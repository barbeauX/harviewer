define(['b', 'c'], function (b, c) {
    return {
        name: 'a',
        b: b,
        c: c
    };
});
