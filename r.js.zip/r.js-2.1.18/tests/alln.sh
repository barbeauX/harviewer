node allNode.js
node ../r.js all.js
node node/syncMap/syncMap.js
node node/pluginLocalId/test.js
node node/syncRequire/main.js
node node/nodeRelative/main.js