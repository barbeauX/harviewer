define({
    name: 'a (should be uppercase)'
});